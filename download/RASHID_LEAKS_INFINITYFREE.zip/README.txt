RASHID LEAKS - InfinityFree Frontend
=====================================

This is the frontend landing page for RASHID LEAKS adult video platform.

DEPLOYMENT INSTRUCTIONS:
1. Upload all files in this folder to your InfinityFree htdocs directory
2. The site will be available at: https://rashidleaks.wuaze.com

WHAT'S INCLUDED:
- index.html - Landing page with age verification
- .htaccess - Server configuration (HTTPS, security headers, caching)

BACKEND:
The main application backend is hosted on Vercel at:
https://caltex-deriv-bot.vercel.app

ADMIN LOGIN:
- URL: https://caltex-deriv-bot.vercel.app/login
- Username: admin
- Password: waynengeno

FEATURES:
- Mobile-responsive design
- Age gate verification (18+)
- Redirects to full platform on Vercel
- SEO optimized
- Security headers configured

SUPPORT:
For issues, contact: admin@rashidleaks.com

© 2026 RASHID LEAKS. All rights reserved.
